# 📖 User Stories & Flujos de Usuario — Momentum

> **Versión:** 1.0 · **Fecha:** Marzo 2026 · [⬇ Descargar .docx](./downloads/momentum_user_stories.docx)

---

## Índice

- [Epic 1 — Autenticación y Onboarding](#epic-1--autenticación-y-onboarding)
- [Epic 2 — Gestión de Tareas](#epic-2--gestión-de-tareas)
- [Epic 3 — Hábitos y Rutinas](#epic-3--hábitos-y-rutinas)
- [Epic 4 — Foco y Productividad](#epic-4--foco-y-productividad)
- [Flujos de Usuario Principales](#flujos-de-usuario-principales)

---

## Epic 1 — Autenticación y Onboarding

Cubre el flujo de registro, inicio de sesión y la experiencia de bienvenida que introduce al usuario a las capacidades de Momentum.

---

### US-01 · Registro con email

> **Como** nuevo usuario, **quiero** registrarme con mi correo y contraseña, **para** poder acceder a mi cuenta desde cualquier dispositivo.

**Criterios de aceptación:**
- [ ] El formulario valida email en formato correcto.
- [ ] La contraseña debe tener mínimo 8 caracteres, una mayúscula y un número.
- [ ] Se envía email de verificación tras el registro.
- [ ] El usuario no puede iniciar sesión sin verificar su email.
- [ ] Mensajes de error claros para cada campo inválido.

**Prioridad:** 🔴 Alta · **Sprint:** S1

---

### US-02 · Inicio de sesión con Google

> **Como** usuario registrado, **quiero** iniciar sesión con mi cuenta de Google en un solo tap, **para** no tener que recordar otra contraseña.

**Criterios de aceptación:**
- [ ] El botón "Continuar con Google" está visible en la pantalla de login.
- [ ] El flujo OAuth completa en menos de 3 pasos.
- [ ] Si el email de Google no existe, se crea cuenta automáticamente.
- [ ] La sesión persiste al cerrar la app.

**Prioridad:** 🔴 Alta · **Sprint:** S1

---

### US-03 · Configurar perfil inicial (Onboarding)

> **Como** nuevo usuario que acaba de registrarse, **quiero** configurar mis áreas de foco y metas personales durante el onboarding, **para** que Momentum pueda ofrecerme sugerencias relevantes desde el primer día.

**Criterios de aceptación:**
- [ ] El onboarding tiene máximo 4 pasos con progreso visible.
- [ ] El usuario puede seleccionar hasta 3 áreas de foco (trabajo, salud, aprendizaje, personal).
- [ ] Cada paso es saltable sin perder el progreso anterior.
- [ ] Al finalizar, el dashboard muestra tareas de ejemplo pre-cargadas según las áreas elegidas.

**Prioridad:** 🔴 Alta · **Sprint:** S1

---

## Epic 2 — Gestión de Tareas

Funcionalidad central de la app: creación, organización, priorización y seguimiento de tareas individuales.

---

### US-04 · Crear tarea rápida

> **Como** usuario activo, **quiero** crear una tarea rápida en menos de 3 segundos, **para** capturar ideas y compromisos al instante sin interrumpir mi flujo.

**Criterios de aceptación:**
- [ ] El botón "+" está siempre visible desde cualquier pantalla.
- [ ] El campo de texto se activa inmediatamente al abrir el modal.
- [ ] Presionar Enter o "Guardar" crea la tarea sin otros pasos obligatorios.
- [ ] La tarea creada aparece inmediatamente en el listado de hoy.
- [ ] Se puede agregar categoría y prioridad de forma opcional.

**Prioridad:** 🔴 Alta · **Sprint:** S1

---

### US-05 · Completar y gestionar tareas

> **Como** usuario con tareas pendientes, **quiero** marcar tareas como completadas y reorganizarlas fácilmente, **para** tener visibilidad clara de mi progreso durante el día.

**Criterios de aceptación:**
- [ ] Swipe a la derecha marca como completada con animación de checkmark.
- [ ] Swipe a la izquierda muestra opciones: editar, posponer, eliminar.
- [ ] Las tareas completadas se mueven al final de la lista con tachado visual.
- [ ] La barra de progreso del día se actualiza en tiempo real.
- [ ] Se puede filtrar por: todas, pendientes, completadas, por categoría.

**Prioridad:** 🔴 Alta · **Sprint:** S1

---

### US-06 · Establecer prioridades y fechas

> **Como** usuario organizado, **quiero** asignar prioridad y fecha de vencimiento a mis tareas, **para** enfocarme en lo más importante primero.

**Criterios de aceptación:**
- [ ] El selector de prioridad usa código de color: rojo (alta), amarillo (media), gris (baja).
- [ ] El date picker es nativo de cada plataforma (iOS y Android).
- [ ] Las tareas vencidas hoy aparecen destacadas en rojo.
- [ ] Las tareas de alta prioridad se ordenan primero por defecto.
- [ ] Se puede ordenar manualmente mediante drag & drop.

**Prioridad:** 🔴 Alta · **Sprint:** S1

---

## Epic 3 — Hábitos y Rutinas

Sistema de seguimiento de hábitos recurrentes con gamificación mediante rachas y estadísticas de consistencia.

---

### US-07 · Crear hábito recurrente

> **Como** usuario que quiere mejorar sus rutinas, **quiero** crear un hábito con frecuencia personalizada, **para** realizar un seguimiento constante de mis compromisos diarios.

**Criterios de aceptación:**
- [ ] Se puede definir hábito como: diario, días específicos de la semana, o intervalo personalizado.
- [ ] El usuario puede asignar un emoji al hábito para identificación visual rápida.
- [ ] Se configura un horario de recordatorio opcional.
- [ ] El hábito aparece en el dashboard en la sección "Hábitos de hoy".
- [ ] Límite de 10 hábitos activos en el plan gratuito.

**Prioridad:** 🔴 Alta · **Sprint:** S1

---

### US-08 · Ver y mantener rachas

> **Como** usuario consistente, **quiero** ver mi racha actual y el historial de los últimos 30 días, **para** que la gamificación me motive a no romper mi racha.

**Criterios de aceptación:**
- [ ] La vista de hábito muestra el número de días consecutivos en grande y destacado.
- [ ] El calendario de los últimos 30 días muestra días cumplidos (verde), omitidos (gris) y fallados (rojo).
- [ ] Al completar un hábito por 7 días seguidos se muestra una animación de celebración.
- [ ] Si se rompe una racha, se muestra mensaje motivacional con opción de "recuperar racha" (plan Pro).

**Prioridad:** 🟡 Media · **Sprint:** S2

---

## Epic 4 — Foco y Productividad

Timer Pomodoro integrado con registro de sesiones de foco y estadísticas de tiempo productivo.

---

### US-09 · Iniciar sesión Pomodoro

> **Como** usuario que necesita concentrarse, **quiero** iniciar un timer Pomodoro vinculado a una tarea específica, **para** saber exactamente en qué estoy trabajando y medir mi tiempo productivo.

**Criterios de aceptación:**
- [ ] El timer muestra 25:00 por defecto con opción de personalizar duración.
- [ ] Se puede seleccionar o buscar la tarea asociada antes de iniciar.
- [ ] El timer continúa funcionando cuando la app va al background.
- [ ] Al terminar, suena una alerta y se registra la sesión automáticamente.
- [ ] La sesión completada suma al contador de "tiempo de foco" en el dashboard.

**Prioridad:** 🔴 Alta · **Sprint:** S2

---

### US-10 · Ver estadísticas de foco

> **Como** usuario analítico, **quiero** ver cuánto tiempo he dedicado al trabajo profundo esta semana, **para** ajustar mis hábitos de trabajo y celebrar mis logros.

**Criterios de aceptación:**
- [ ] La pantalla muestra: total de minutos de foco hoy, esta semana, este mes.
- [ ] Gráfico de barras con distribución de foco por día de la semana.
- [ ] Distribución de foco por categoría de tarea.
- [ ] Indicador visual de si se superó o no la meta semanal de horas de foco.

**Prioridad:** 🟡 Media · **Sprint:** S3

---

## Flujos de Usuario Principales

### Flujo 1 — Primer uso: Registro y Onboarding

```
1. Usuario descarga Momentum desde App Store / Google Play
2. Pantalla de bienvenida → botón "Comenzar gratis"
3. Selección de método: Email o Google
4. Si elige email → formulario → verificación por email
5. Onboarding paso 1: ¿Cuáles son tus áreas prioritarias? (selección múltiple)
6. Onboarding paso 2: ¿Cuál es tu mayor desafío? (opciones predefinidas)
7. Onboarding paso 3: Configura tu primera tarea del día (opcional)
8. Dashboard con tareas de ejemplo + tutorial superpuesto (tooltips)
```

---

### Flujo 2 — Uso diario habitual

```
1. Usuario abre app (posiblemente desde notificación push matutina)
2. Dashboard → saludo personalizado, fecha, check-in de estado de ánimo
3. Registra estado de ánimo del día tocando un emoji
4. Revisa lista de tareas pendientes, marca completadas con swipe
5. Inicia sesión Pomodoro para una tarea importante
6. Timer: 25 min trabajo → 5 min descanso → repite
7. Al finalizar el día, revisa barra de progreso y hábitos completados
8. Recibe resumen nocturno automático con logros del día
```
