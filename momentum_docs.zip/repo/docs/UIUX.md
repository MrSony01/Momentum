# 🎨 Guía de Diseño UI/UX — Momentum

> **Versión:** 1.0 · **Fecha:** Marzo 2026 · [⬇ Descargar .docx](./downloads/momentum_uiux.docx)

---

## Índice

- [1. Principios de Diseño](#1-principios-de-diseño)
- [2. Sistema de Color](#2-sistema-de-color)
- [3. Tipografía](#3-tipografía)
- [4. Espaciado y Grid](#4-espaciado-y-grid)
- [5. Componentes Clave](#5-componentes-clave)
- [6. Mapa de Pantallas](#6-mapa-de-pantallas)
- [7. Animaciones y Microinteracciones](#7-animaciones-y-microinteracciones)
- [8. Accesibilidad](#8-accesibilidad)

---

## 1. Principios de Diseño

| Principio | Definición y Aplicación |
|-----------|------------------------|
| **Impulso visible** | El usuario debe sentir progreso en todo momento. Barras de avance, contadores y rachas son protagonistas, no decorativos. |
| **Fricción mínima** | Agregar una tarea o registrar un hábito no puede tomar más de 3 taps. El camino crítico es siempre el más corto. |
| **Feedback inmediato** | Cada acción genera respuesta visual y háptica instantánea. Sin acciones silenciosas. |
| **Motivación contextual** | Los mensajes de motivación son relevantes al momento. No son mensajes genéricos. |
| **Oscuridad amigable** | El modo oscuro es el modo por defecto. Diseñado para uso nocturno sin fatiga visual. |

---

## 2. Sistema de Color

### 2.1 Paleta Principal

| Token | Hex | Uso |
|-------|-----|-----|
| `--color-bg` | `#0C0C10` | Fondo principal de la app |
| `--color-surface` | `#14141A` | Tarjetas, modales, bottom sheets |
| `--color-surface-2` | `#1C1C25` | Inputs, items de lista, hover states |
| `--color-accent` | `#C8F04E` | CTAs primarios, progreso, rachas activas |
| `--color-purple` | `#7B5EF8` | Timer, foco, funciones Pro |
| `--color-coral` | `#F04E7B` | Alertas, prioridad alta, vencimiento |
| `--color-text` | `#F0F0EE` | Texto principal |
| `--color-muted` | `#6B6B7A` | Labels secundarios, placeholders |

### 2.2 Semántica de Prioridades

```
🔴 Alta      #F04E7B  →  punto 6dp + texto coral
🟡 Media     #C8F04E  →  punto 6dp + texto lima
⚪ Baja      #6B6B7A  →  punto 6dp, sin énfasis
✅ Completada          →  texto tachado en color muted
```

---

## 3. Tipografía

| Token | Fuente | Tamaño | Peso | Uso |
|-------|--------|--------|------|-----|
| `display-xl` | Syne | 32sp | 800 | Timer Pomodoro, número de racha destacado |
| `heading-lg` | Syne | 24sp | 700 | Título de pantalla, saludo del dashboard |
| `heading-sm` | Syne | 18sp | 700 | Títulos de sección, nombres de hábito |
| `body-lg` | DM Sans | 16sp | 400 | Título de tarea, contenido principal |
| `body-sm` | DM Sans | 13sp | 400 | Metadatos, tags, fechas, labels |
| `label` | DM Sans | 11sp | 600 | Labels de navegación, caps de sección |
| `caption` | DM Sans | 10sp | 400 | Timestamps, notas de pie, tooltips |

---

## 4. Espaciado y Grid

### 4.1 Tokens de Espaciado (base 4dp)

| Token | Valor | Uso |
|-------|-------|-----|
| `space-xs` | 4dp | Gap entre ícono y texto, separación interna de chips |
| `space-sm` | 8dp | Padding interno de tags, gap entre meta-items |
| `space-md` | 16dp | Padding lateral estándar, gap entre cards |
| `space-lg` | 24dp | Padding de tarjetas, margen entre secciones |
| `space-xl` | 32dp | Separación entre epics, espaciado del timer |
| `space-2xl` | 48dp | Padding top de pantallas, zonas de touch safety |

### 4.2 Layout y Safe Areas

- **Margen horizontal global:** 16dp (contenido) / 0dp (pantallas full-bleed como timer)
- **Bottom navigation bar:** 64dp + safe area inset
- **Top header:** 56dp + status bar height
- **Touch target mínimo:** 44×44dp (iOS HIG) / 48×48dp (Android Material)
- **Border radius:** cards (16dp) · chips (99dp) · botones (12dp)

---

## 5. Componentes Clave

### Task Item

Anatomía: `indicador prioridad (6dp)` → `checkbox (20dp, radius 6dp)` → `contenido (título + tags + meta)` → `fecha vencimiento`

- Altura mínima: **64dp**
- Swipe derecha → completar
- Swipe izquierda → opciones (editar / posponer / eliminar)

### Habit Tracker Row

`emoji (32dp)` → `nombre` → `badge racha` → `grid 7 días (28×28dp, radius 8dp)`

| Estado del día | Visual |
|----------------|--------|
| Completado | Fondo `#C8F04E` |
| Omitido | Fondo gris tenue |
| Fallado | Fondo `#F04E7B` tenue |
| Hoy | Borde `#C8F04E` |

### Pomodoro Timer

- Pantalla full-bleed con fondo degradado púrpura oscuro
- Display tiempo: Syne 800 · 72sp · centrado
- Progress ring SVG: 240dp de diámetro
- Botón principal: 240dp ancho · 56dp alto · radius 28dp
- 4 dots de sesiones completadas bajo el timer

### Stat Card

- Tamaño: 160×100dp
- Estructura: `label (11sp caps)` → `valor (Syne 700, 36sp, color acento)` → `descripción (13sp muted)`
- Línea inferior de 2dp en color de acento
- Grid de 2×2 en el dashboard

---

## 6. Mapa de Pantallas

| # | Pantalla | Contenido | Tab |
|---|----------|-----------|-----|
| S01 | Splash / Bienvenida | Logo animado, tagline, botones de ingreso | — |
| S02 | Registro | Formulario email/pass + opción Google | — |
| S03 | Onboarding (×3) | Áreas de foco, desafíos, primera tarea | — |
| S04 | Dashboard / Hoy | Saludo, check-in ánimo, stats, tareas, hábitos | Inicio |
| S05 | Tareas | Lista completa con filtros, búsqueda y ordenamiento | Tareas |
| S06 | Nueva Tarea (modal) | Bottom sheet: título, categoría, prioridad, fecha | — |
| S07 | Timer Foco | Pomodoro full-bleed con tarea activa | Foco |
| S08 | Hábitos | Grid del día, historial semanal, rachas | Hábitos |
| S09 | Estadísticas | Gráficos de tareas, foco acumulado, hábitos | Stats |
| S10 | Perfil / Ajustes | Avatar, notificaciones, tema, plan, cerrar sesión | Perfil |

---

## 7. Animaciones y Microinteracciones

| Evento | Tipo | Especificación |
|--------|------|----------------|
| Completar tarea | Spring | Checkbox escala 1→1.2→1, 200ms + vibración háptica suave |
| Pomodoro completo | Celebración | Ring verde, confetti 1.5s, notificación push, vibración media |
| Racha nueva máxima | Modal | Bottom sheet celebratorio con número animado (count up) |
| Swipe de tarea | Gesture | Fondo aparece al 30%, ícono al 50%, acción confirma al 75% |
| Transición pantallas | Slide | Slide horizontal 300ms (stack) / fade 200ms (tabs) |
| Carga inicial | Stagger | Cards en cascada top-to-bottom, 60ms de delay entre cada una |

---

## 8. Accesibilidad

- Todas las acciones interactivas tienen `accessibilityLabel` descriptivo en español.
- Imágenes e iconos decorativos usan `accessibilityRole="none"`.
- Contraste de texto cumple **WCAG 2.1 AA** (mínimo 4.5:1 texto normal, 3:1 texto grande).
- El tamaño de texto respeta Dynamic Type (iOS) y Font Scale (Android) hasta 200%.
- Los colores nunca son el único indicador de estado: siempre se complementan con formas o texto.
- Los gestos de swipe tienen alternativa en menú de opciones con long press.
- Focus order lógico en todos los formularios, navegable con teclado externo.
