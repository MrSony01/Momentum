# 📋 Product Requirements Document — Momentum

> **Versión:** 1.0 · **Fecha:** Marzo 2026 · [⬇ Descargar .docx](./downloads/momentum_prd.docx)

---

## 1. Visión General

### 1.1 Descripción

Momentum es una aplicación móvil nativa diseñada para mejorar la productividad y organización personal. Su propósito es ayudar a los usuarios a mantener el impulso en sus actividades diarias, semanales y mensuales mediante un sistema intuitivo de gestión de tareas, hábitos y rutinas.

### 1.2 Problema que Resuelve

Los usuarios pierden el hilo de sus compromisos personales y profesionales porque las herramientas actuales son demasiado complejas, no generan hábitos sostenibles, o carecen de mecanismos de motivación efectivos. Momentum cierra esa brecha.

### 1.3 Objetivos de Negocio

- Alcanzar **10.000 usuarios activos mensuales** en los primeros 6 meses post-lanzamiento.
- Lograr una **retención del 40%** a los 30 días.
- Monetizar mediante suscripción mensual (Plan Pro) con **conversión del 8%** del total de usuarios.
- Posicionar Momentum como la app de productividad **#1 en el mercado hispanohablante**.

---

## 2. Usuarios Objetivo

### 2.1 Perfil Principal

| Atributo | Descripción |
|----------|-------------|
| **Edad** | 22 – 38 años |
| **Ocupación** | Profesionales, estudiantes universitarios, emprendedores |
| **Dispositivos** | iOS y Android (smartphone como herramienta principal) |
| **Motivación** | Mejorar productividad, cumplir metas personales y profesionales |
| **Frustración** | Apps complejas, falta de motivación, olvidar compromisos |

### 2.2 Segmentos Secundarios

- Personas en búsqueda activa de bienestar y hábitos saludables.
- Equipos pequeños (2–5 personas) que quieren coordinar tareas.
- Coaches y mentores que acompañan procesos de desarrollo personal.

---

## 3. Funcionalidades Requeridas

### 3.1 MVP — Funcionalidades Core

| ID | Módulo | Descripción | Prioridad | Sprint |
|----|--------|-------------|-----------|--------|
| F-01 | Gestión de Tareas | Crear, editar, completar y eliminar tareas con categoría, prioridad y fecha de vencimiento | 🔴 Alta | S1 |
| F-02 | Hábitos Recurrentes | Definir hábitos diarios/semanales con seguimiento de racha y notificaciones | 🔴 Alta | S1 |
| F-03 | Timer Pomodoro | Sesiones de foco de 25 min con breaks automáticos y conteo de sesiones | 🔴 Alta | S2 |
| F-04 | Dashboard Diario | Vista principal con resumen del día, estadísticas de progreso y accesos rápidos | 🔴 Alta | S2 |
| F-05 | Registro de Estado de Ánimo | Check-in diario con historial y correlación de productividad | 🟡 Media | S3 |
| F-06 | Autenticación | Registro e inicio de sesión con email/password y Google Sign-In | 🔴 Alta | S1 |
| F-07 | Notificaciones Push | Recordatorios de tareas, hábitos y sesiones de foco programables | 🔴 Alta | S2 |
| F-08 | Reportes Semanales | Resumen automático con métricas de productividad, hábitos y tiempo de foco | 🟡 Media | S3 |

### 3.2 Funcionalidades Post-MVP (v2.0)

- Proyectos colaborativos con invitación de miembros.
- Integración con Google Calendar y Apple Calendar.
- IA: sugerencia automática de horarios óptimos.
- Widgets nativos para pantalla de inicio (iOS y Android).
- Exportación de datos en PDF y CSV.
- Modo sin conexión completo con sincronización diferida.

---

## 4. Requerimientos No Funcionales

| Categoría | Requerimiento | Métrica de Aceptación |
|-----------|---------------|----------------------|
| **Rendimiento** | La app debe cargar en menos de 2 segundos | Time to Interactive < 2s en 4G |
| **Disponibilidad** | Alta disponibilidad del servicio backend | Uptime >= 99.5% mensual |
| **Seguridad** | Datos cifrados en tránsito y en reposo | TLS 1.3, AES-256 en base de datos |
| **Usabilidad** | Onboarding completable sin instrucciones externas | Tasa de completitud >= 85% |
| **Accesibilidad** | Soporte para texto dinámico y lectores de pantalla | Cumplimiento WCAG 2.1 nivel AA |
| **Escalabilidad** | Arquitectura que soporte crecimiento sin rediseño | Hasta 100.000 usuarios sin cambios arquitecturales |

---

## 5. Stack Tecnológico

| Capa | Tecnología | Justificación |
|------|------------|---------------|
| Frontend (App) | React Native + Expo | Código compartido iOS/Android, ecosistema maduro |
| Navegación | React Navigation v6 | Estándar de facto en React Native |
| Estado global | Zustand + React Query | Ligero, fácil de testear, caché automático |
| Base de datos local | SQLite (expo-sqlite) | Soporte offline, rendimiento excelente |
| Backend / BaaS | Supabase (PostgreSQL) | Auth, DB, Storage y Realtime en una plataforma |
| Notificaciones | Expo Notifications | API unificada para iOS y Android |
| Analytics | Mixpanel | Seguimiento de eventos de producto granular |

---

## 6. KPIs y Criterios de Éxito

| Métrica | Meta 3 meses | Meta 6 meses |
|---------|-------------|-------------|
| Usuarios activos diarios (DAU) | 2.000 | 8.000 |
| Retención D30 | 35% | 40% |
| Tasa de conversión a Pro | 5% | 8% |
| NPS | >= 40 | >= 55 |
| Tareas creadas por usuario / día | 3 | 5 |
| Crash-free sessions | >= 99% | >= 99.5% |

---

## 7. Roadmap

| Sprint | Período | Entregables |
|--------|---------|-------------|
| **S1** | Semanas 1–2 | Autenticación, CRUD de tareas, arquitectura base |
| **S2** | Semanas 3–4 | Hábitos, Pomodoro timer, notificaciones push |
| **S3** | Semanas 5–6 | Dashboard, estado de ánimo, reportes, diseño final |
| **Beta** | Semanas 7–8 | Beta cerrado, bugs, pruebas de usuario |
| **v1.0** | Semana 9+ | Lanzamiento en App Store y Google Play |

---

## 8. Riesgos y Mitigaciones

| Riesgo | Impacto | Plan de Mitigación |
|--------|---------|-------------------|
| Baja adopción inicial | Alto | Beta testers, estrategia de marketing pre-lanzamiento |
| Diferencias UX iOS/Android | Medio | Pruebas en dispositivos físicos desde S1, seguir HIG y Material Design |
| Rendimiento sincronización offline | Medio | Conflict resolution con SQLite como fuente de verdad local |
| Abandono por complejidad percibida | Alto | Onboarding gamificado, progressive disclosure, tutoriales contextuales |
