<div align="center">

# ⚡ Momentum

**Mantén el impulso en tus actividades diarias, semanales y mensuales.**

[![Estado](https://img.shields.io/badge/estado-en%20desarrollo-C8F04E?style=flat-square)](.)
[![Plataforma](https://img.shields.io/badge/plataforma-iOS%20%7C%20Android-7B5EF8?style=flat-square)](.)
[![Stack](https://img.shields.io/badge/stack-React%20Native%20%2B%20Supabase-F04E7B?style=flat-square)](.)
[![Versión](https://img.shields.io/badge/versión-0.1.0--alpha-blue?style=flat-square)](.)

</div>

---

## ¿Qué es Momentum?

Momentum es una aplicación móvil diseñada para mejorar la productividad y organización personal mediante la gestión inteligente de tareas y rutinas. Su objetivo principal es ayudar a las personas a **mantener el impulso** en sus actividades diarias, semanales y mensuales, ofreciendo un sistema intuitivo que motiva y recuerda los compromisos adquiridos.

---

## ✨ Funcionalidades principales

| Módulo | Descripción | Estado |
|--------|-------------|--------|
| ⚡ Gestión de Tareas | Crear, priorizar y completar tareas con categorías y fechas | 🔜 Sprint 1 |
| 🔁 Hábitos Recurrentes | Seguimiento de hábitos con rachas y recordatorios | 🔜 Sprint 1 |
| 🎯 Timer Pomodoro | Sesiones de foco de 25 min con registro automático | 🔜 Sprint 2 |
| 📊 Dashboard Diario | Vista de progreso del día con estadísticas en tiempo real | 🔜 Sprint 2 |
| 💭 Estado de Ánimo | Check-in diario de bienestar correlacionado con productividad | 🔜 Sprint 3 |
| 📈 Reportes Semanales | Resumen automático de métricas y logros | 🔜 Sprint 3 |

---

## 🗂️ Documentación

Toda la documentación del proyecto vive en la carpeta [`/docs`](./docs).

| Documento | Ver en GitHub | Descargar |
|-----------|--------------|-----------|
| 📋 Product Requirements (PRD) | [`PRD.md`](./docs/PRD.md) | [`momentum_prd.docx`](./docs/downloads/momentum_prd.docx) |
| 📖 User Stories & Flujos | [`USER_STORIES.md`](./docs/USER_STORIES.md) | [`momentum_user_stories.docx`](./docs/downloads/momentum_user_stories.docx) |
| 🎨 Guía de Diseño UI/UX | [`UIUX.md`](./docs/UIUX.md) | [`momentum_uiux.docx`](./docs/downloads/momentum_uiux.docx) |

---

## 🛠️ Stack Tecnológico

```
Frontend      →  React Native + Expo
Navegación    →  React Navigation v6
Estado        →  Zustand + React Query
DB Local      →  SQLite (expo-sqlite)
Backend       →  Supabase (PostgreSQL)
Notificaciones→  Expo Notifications
Analytics     →  Mixpanel
```

---

## 🗺️ Roadmap

```
Sprint 1  (Sem 1–2)  →  Autenticación · CRUD de tareas · Arquitectura base
Sprint 2  (Sem 3–4)  →  Hábitos · Pomodoro · Notificaciones push
Sprint 3  (Sem 5–6)  →  Dashboard · Estado de ánimo · Reportes · Diseño final
Beta      (Sem 7–8)  →  Beta cerrado · Corrección de bugs · Pruebas de usuario
v1.0      (Sem 9+)   →  Lanzamiento en App Store y Google Play
```

---

## 📁 Estructura del Proyecto

```
momentum/
├── README.md
├── docs/
│   ├── PRD.md
│   ├── USER_STORIES.md
│   ├── UIUX.md
│   └── downloads/
│       ├── momentum_prd.docx
│       ├── momentum_user_stories.docx
│       └── momentum_uiux.docx
├── src/                  # (próximamente)
│   ├── app/
│   ├── components/
│   ├── screens/
│   ├── store/
│   └── lib/
└── ...
```

---

## 📄 Licencia

Este proyecto está bajo licencia MIT. Ver [`LICENSE`](./LICENSE) para más detalles.
